import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'discord-board',
  description: 'A live directory of Discord-authenticated members.',
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
