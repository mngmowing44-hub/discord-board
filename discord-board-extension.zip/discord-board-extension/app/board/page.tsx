import { redirect } from 'next/navigation';
import { getSession } from '@/lib/auth/session';
import { supabaseAdmin } from '@/lib/supabase/admin';
import BulletinBoard from '@/components/BulletinBoard';
import Header from '@/components/Header';
import type { BoardUser } from '@/lib/types';

export const dynamic = 'force-dynamic';

export default async function BoardPage() {
  const session = await getSession();
  if (!session) redirect('/');

  const { data, error } = await supabaseAdmin()
    .from('users')
    .select('*')
    .order('last_seen', { ascending: false })
    .limit(200);

  if (error) {
    console.error('[board] failed to load users', error);
  }

  const initial = (data ?? []) as BoardUser[];

  return (
    <>
      <Header username={session.username} />
      <main className="board-main">
        <BulletinBoard initial={initial} currentDiscordId={session.discord_id} />
      </main>
    </>
  );
}
