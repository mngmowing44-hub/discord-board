import { redirect } from 'next/navigation';
import { getSession } from '@/lib/auth/session';
import LoginButton from '@/components/LoginButton';
import Icon from '@/components/Icon';

interface PageProps {
  searchParams: Promise<{ error?: string }>;
}

export default async function HomePage({ searchParams }: PageProps) {
  const session = await getSession();
  if (session) redirect('/board');

  const params = await searchParams;
  const errorMsg = errorMessage(params.error);

  return (
    <main className="landing">
      <div className="landing__inner fade-in">
        <div className="landing__mark" aria-hidden>
          <Icon name="board" size={24} />
        </div>
        <h1 className="landing__title">discord-board</h1>
        <p className="landing__subtitle">A live directory of who&rsquo;s here.</p>
        <LoginButton />
        {errorMsg && <p className="landing__error">{errorMsg}</p>}
      </div>
    </main>
  );
}

function errorMessage(code: string | undefined): string | null {
  switch (code) {
    case 'denied':
      return 'Login was cancelled.';
    case 'state_mismatch':
      return 'Session expired. Please try again.';
    case 'oauth_failed':
      return 'Could not sign in with Discord.';
    case 'db_error':
      return 'Could not save your profile.';
    case 'invalid_request':
      return 'Invalid login link.';
    default:
      return null;
  }
}
