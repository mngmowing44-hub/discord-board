import { NextResponse } from 'next/server';
import { cookies } from 'next/headers';
import { randomBytes } from 'node:crypto';
import { discordLoginUrl } from '@/lib/auth/discord';

export const runtime = 'nodejs';

export async function GET() {
  const state = randomBytes(16).toString('hex');

  const store = await cookies();
  store.set('oauth_state', state, {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    path: '/',
    maxAge: 60 * 5, // 5 minutes
  });

  return NextResponse.redirect(discordLoginUrl(state));
}
