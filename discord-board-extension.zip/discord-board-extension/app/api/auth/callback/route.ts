import { NextRequest, NextResponse } from 'next/server';
import { cookies } from 'next/headers';
import {
  exchangeCode,
  fetchDiscordUser,
  avatarUrl,
  bannerUrl,
  bannerColor,
} from '@/lib/auth/discord';
import { snowflakeToDate } from '@/lib/auth/snowflake';
import { supabaseAdmin } from '@/lib/supabase/admin';
import { createSession } from '@/lib/auth/session';

export const runtime = 'nodejs';

function fail(req: NextRequest, code: string) {
  const url = new URL('/', req.url);
  url.searchParams.set('error', code);
  return NextResponse.redirect(url);
}

export async function GET(req: NextRequest) {
  const sp = req.nextUrl.searchParams;
  const code = sp.get('code');
  const state = sp.get('state');
  const oauthError = sp.get('error');

  if (oauthError) return fail(req, 'denied');
  if (!code || !state) return fail(req, 'invalid_request');

  const store = await cookies();
  const expected = store.get('oauth_state')?.value;
  store.delete('oauth_state');

  if (!expected || expected !== state) return fail(req, 'state_mismatch');

  try {
    const { access_token } = await exchangeCode(code);
    const user = await fetchDiscordUser(access_token);

    // Upsert without `bio` so existing bios are preserved on subsequent logins.
    const row = {
      discord_id: user.id,
      username: user.global_name ?? user.username,
      avatar_url: avatarUrl(user),
      banner_url: bannerUrl(user),
      banner_color: bannerColor(user),
      account_created_at: snowflakeToDate(user.id).toISOString(),
      last_seen: new Date().toISOString(),
    };

    const { error: dbError } = await supabaseAdmin()
      .from('users')
      .upsert(row, { onConflict: 'discord_id' });

    if (dbError) {
      console.error('[auth/callback] upsert failed', dbError);
      return fail(req, 'db_error');
    }

    await createSession({
      discord_id: user.id,
      username: row.username,
    });

    return NextResponse.redirect(new URL('/board', req.url));
  } catch (err) {
    console.error('[auth/callback] error', err);
    return fail(req, 'oauth_failed');
  }
}
