export interface BoardUser {
  id: string;
  discord_id: string;
  username: string;
  avatar_url: string | null;
  banner_url: string | null;
  banner_color: string | null;
  bio: string | null;
  account_created_at: string;
  last_seen: string;
  created_at: string;
  updated_at: string;
}
