'use client';

import { createClient } from '@supabase/supabase-js';

/**
 * Browser-side Supabase client.
 * Uses the public anon key — RLS only permits SELECT on `users`.
 * All writes happen through server routes via the service-role admin client.
 */
export const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
  {
    auth: { persistSession: false, autoRefreshToken: false },
    realtime: { params: { eventsPerSecond: 5 } },
  },
);
