import 'server-only';

const DISCORD_API = 'https://discord.com/api/v10';
const DISCORD_CDN = 'https://cdn.discordapp.com';

export interface DiscordUser {
  id: string;
  username: string;
  global_name: string | null;
  avatar: string | null;
  banner: string | null;
  accent_color: number | null;
}

interface TokenResponse {
  access_token: string;
  token_type: string;
  expires_in: number;
  refresh_token: string;
  scope: string;
}

function requireEnv(name: string): string {
  const v = process.env[name];
  if (!v) throw new Error(`Missing required env var: ${name}`);
  return v;
}

export function discordLoginUrl(state: string): string {
  const params = new URLSearchParams({
    client_id: requireEnv('DISCORD_CLIENT_ID'),
    redirect_uri: requireEnv('DISCORD_REDIRECT_URI'),
    response_type: 'code',
    scope: 'identify',
    state,
    prompt: 'none',
  });
  return `${DISCORD_API}/oauth2/authorize?${params.toString()}`;
}

export async function exchangeCode(code: string): Promise<TokenResponse> {
  const body = new URLSearchParams({
    client_id: requireEnv('DISCORD_CLIENT_ID'),
    client_secret: requireEnv('DISCORD_CLIENT_SECRET'),
    grant_type: 'authorization_code',
    code,
    redirect_uri: requireEnv('DISCORD_REDIRECT_URI'),
  });

  const res = await fetch(`${DISCORD_API}/oauth2/token`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body,
    cache: 'no-store',
  });

  if (!res.ok) {
    const detail = await res.text().catch(() => '');
    throw new Error(`Discord token exchange failed (${res.status}): ${detail}`);
  }
  return res.json();
}

export async function fetchDiscordUser(accessToken: string): Promise<DiscordUser> {
  const res = await fetch(`${DISCORD_API}/users/@me`, {
    headers: { Authorization: `Bearer ${accessToken}` },
    cache: 'no-store',
  });
  if (!res.ok) {
    throw new Error(`Discord user fetch failed (${res.status})`);
  }
  return res.json();
}

export function avatarUrl(user: DiscordUser): string | null {
  if (!user.avatar) return null;
  const ext = user.avatar.startsWith('a_') ? 'gif' : 'png';
  return `${DISCORD_CDN}/avatars/${user.id}/${user.avatar}.${ext}?size=256`;
}

export function bannerUrl(user: DiscordUser): string | null {
  if (!user.banner) return null;
  const ext = user.banner.startsWith('a_') ? 'gif' : 'png';
  return `${DISCORD_CDN}/banners/${user.id}/${user.banner}.${ext}?size=600`;
}

export function bannerColor(user: DiscordUser): string | null {
  if (user.accent_color == null) return null;
  return `#${user.accent_color.toString(16).padStart(6, '0')}`;
}
