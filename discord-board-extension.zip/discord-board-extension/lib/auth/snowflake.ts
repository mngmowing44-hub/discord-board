/**
 * Discord snowflake decoding.
 * @see https://discord.com/developers/docs/reference#snowflakes
 *
 * The first 42 bits of a snowflake encode milliseconds since the Discord epoch
 * (Jan 1, 2015). Shifting right by 22 bits and adding the epoch yields a
 * standard unix timestamp.
 */

const DISCORD_EPOCH = 1420070400000n;

export function snowflakeToDate(snowflake: string): Date {
  const ms = (BigInt(snowflake) >> 22n) + DISCORD_EPOCH;
  return new Date(Number(ms));
}

export function accountAge(snowflake: string): string {
  const created = snowflakeToDate(snowflake);
  const ms = Date.now() - created.getTime();

  const day = 24 * 60 * 60 * 1000;
  const year = 365.25 * day;
  const month = 30.44 * day;

  if (ms >= year) {
    const y = Math.floor(ms / year);
    return `${y} year${y === 1 ? '' : 's'}`;
  }
  if (ms >= month) {
    const m = Math.floor(ms / month);
    return `${m} month${m === 1 ? '' : 's'}`;
  }
  const d = Math.max(1, Math.floor(ms / day));
  return `${d} day${d === 1 ? '' : 's'}`;
}
