/**
 * Format an ISO timestamp as a quiet, human-readable relative string.
 *
 * Anything within 2 minutes is treated as "online" — the heartbeat in
 * useUsers fires roughly every 60s.
 */
export function relativeTime(iso: string): string {
  const then = new Date(iso).getTime();
  const ms = Date.now() - then;

  if (ms < 2 * 60 * 1000) return 'online';

  const m = Math.floor(ms / 60_000);
  if (m < 60) return `${m}m ago`;

  const h = Math.floor(m / 60);
  if (h < 24) return `${h}h ago`;

  const d = Math.floor(h / 24);
  if (d < 30) return `${d}d ago`;

  return new Date(iso).toLocaleDateString();
}
