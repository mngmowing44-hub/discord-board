# discord-board — extension files

A drop-in addition for the existing **`discord-board`** Next.js (App Router) project. Adds Discord OAuth, a Supabase-backed users directory, and a live-updating bulletin board UI.

> **Note:** This package _extends_ the existing project. Copy the files into your repo, do not replace your existing setup.

---

## What's in the box

```
app/
  api/auth/login/route.ts          Initiates Discord OAuth (sets state cookie)
  api/auth/callback/route.ts       Handles redirect, exchanges code, upserts user
  api/auth/logout/route.ts         Clears the session cookie
  api/presence/route.ts            Heartbeat endpoint that bumps last_seen
  board/page.tsx                   The bulletin board (server component)
  page.tsx                         Landing / login page
  layout.tsx                       Root layout
  globals.css                      All styling (minimal, OS-native)

components/
  BulletinBoard.tsx                Owns realtime subscription + heartbeat
  UserCard.tsx                     Banner / avatar / name / bio / meta
  Header.tsx                       Sticky translucent header
  LoginButton.tsx                  Pill-style "Continue with Discord" button
  Icon.tsx                         Custom thin-stroke SVG icon set

hooks/
  useUsers.ts                      Subscribes to postgres_changes on `users`

lib/
  supabase/client.ts               Browser client (anon key)
  supabase/admin.ts                Server-only client (service role)
  auth/discord.ts                  OAuth helpers + asset URL builders
  auth/session.ts                  Signed-JWT cookie session (jose)
  auth/snowflake.ts                Discord snowflake → Date / age
  format.ts                        Relative time formatter
  types.ts                         BoardUser type

supabase/
  migrations/0001_create_users_directory.sql   Schema (already applied)

.env.example                       Required environment variables
package.dependencies.json          Two deps to merge into package.json
```

---

## 1. Install dependencies

Add these to your existing `package.json`:

```bash
npm install @supabase/supabase-js jose
```

> If your project doesn't already have an `@/*` path alias configured in `tsconfig.json`, add:
>
> ```json
> { "compilerOptions": { "paths": { "@/*": ["./*"] } } }
> ```

## 2. Configure Discord OAuth

1. Go to <https://discord.com/developers/applications> and create (or open) an application.
2. **OAuth2 → Redirects** — add `http://localhost:3000/api/auth/callback` (and your production URL when you deploy).
3. From the same page, copy the **Client ID** and **Client Secret**.

## 3. Configure environment variables

Copy `.env.example` to `.env.local` and fill it in:

```bash
cp .env.example .env.local
```

| Variable | Where to find it |
| --- | --- |
| `NEXT_PUBLIC_SUPABASE_URL` | Supabase dashboard → Project Settings → API → Project URL |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | Same page → `anon public` key |
| `SUPABASE_SERVICE_ROLE_KEY` | Same page → `service_role` key (**server only — never commit**) |
| `DISCORD_CLIENT_ID` | Discord Developer Portal → your app |
| `DISCORD_CLIENT_SECRET` | Discord Developer Portal → your app → OAuth2 |
| `DISCORD_REDIRECT_URI` | Must exactly match the value registered in Discord |
| `SESSION_SECRET` | Run `openssl rand -hex 32` |

## 4. Database

The schema has **already been applied** to your `discord board` Supabase project. The SQL is committed at `supabase/migrations/0001_create_users_directory.sql` for repo parity, branching, and disaster recovery.

The schema:

- `public.users` table with `discord_id` unique, full Discord profile fields, and timestamps
- Auto-updating `updated_at` trigger (with hardened `search_path`)
- RLS enabled — public `SELECT`, no client-side writes (service role bypass only)
- Realtime publication added on the `users` table

## 5. Run

```bash
npm run dev
```

Open <http://localhost:3000>, click **Continue with Discord**, and your card appears on the board.

---

## How it works

### Auth flow

1. User clicks **Continue with Discord** → `GET /api/auth/login` sets a 5-minute `oauth_state` cookie and redirects to Discord.
2. Discord redirects back to `GET /api/auth/callback?code=…&state=…`.
3. Callback validates state (CSRF), exchanges `code` for an access token, fetches `/users/@me`.
4. The user row is **upserted** into `public.users` keyed on `discord_id`. `bio` is intentionally _not_ included in the upsert so existing bios are preserved on re-login.
5. A 30-day signed JWT cookie (`db_session`, HttpOnly, SameSite=Lax) is set with just `discord_id` and `username`.
6. User is redirected to `/board`.

### Live updates

- `useUsers(initial)` subscribes to `postgres_changes` on `public.users` for INSERT, UPDATE, and DELETE events and keeps the array sorted by `last_seen` desc.
- New logins → INSERT or UPDATE → card appears or moves to the top in real time.

### Presence

- `BulletinBoard` POSTs to `/api/presence` on mount, on tab visibility change, and every 60 s while the tab is visible.
- Cards show **online** (green dot) when `last_seen` is within the last 2 minutes; otherwise relative time.

### Security

- `service_role` key is imported only inside `import 'server-only'` modules — Next.js will throw a build-time error if it leaks to a client component.
- Browser writes to `users` are blocked by RLS — only the server can insert or update.
- Session cookies are HttpOnly, SameSite=Lax, signed with `SESSION_SECRET`.
- OAuth state is verified on every callback.

### Snowflake → date

`account_created_at` is derived from the Discord snowflake ID:

```
ms = (snowflake >> 22) + 1420070400000   // Discord epoch
```

### Banner fallback chain

1. `banner_url` (if Discord returns a banner hash)
2. `banner_color` (Discord `accent_color` rendered as `#rrggbb`)
3. Subtle neutral gradient

---

## Testing checklist

**Auth**

- [ ] Click login → redirects to Discord
- [ ] Discord redirect back lands on `/board`
- [ ] Refresh page — still logged in (session persists)
- [ ] Sign out — back to landing
- [ ] Tamper with `oauth_state` cookie — `state_mismatch` error

**Database**

- [ ] First login — new row in `public.users`
- [ ] Re-login — existing row updated, no duplicate (verify in Supabase Table Editor)
- [ ] Set a `bio` directly in Supabase — re-login does NOT clear it

**Board**

- [ ] Cards render with correct avatar, name, banner
- [ ] Open a second browser, log in as a different Discord account → new card appears on the first browser without refresh
- [ ] Card with no banner shows `banner_color` if available, otherwise gradient
- [ ] `Last seen` shows **online** while tab is open, transitions to `Xm ago` after closing/leaving

**UI**

- [ ] Cards reflow cleanly from 1 column (mobile) to N (desktop)
- [ ] Hover states are subtle, no aggressive motion
- [ ] Honors `prefers-color-scheme` — dark mode looks intentional
- [ ] Honors `prefers-reduced-motion`

---

## Troubleshooting

**`SESSION_SECRET must be set and at least 32 characters`** — generate one with `openssl rand -hex 32`.

**Discord returns `redirect_uri_mismatch`** — the value of `DISCORD_REDIRECT_URI` must match _exactly_ the URL registered in Discord (scheme, host, port, path).

**New users don't appear in real time** — confirm the `users` table is in the `supabase_realtime` publication. The migration adds it; check **Database → Publications** in the dashboard.

**`Module not found: 'server-only'`** — this package ships with Next.js. Make sure your Next.js version is 13.4+.
