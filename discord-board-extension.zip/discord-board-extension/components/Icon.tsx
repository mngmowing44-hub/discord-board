import { SVGProps } from 'react';

type IconName = 'discord' | 'board' | 'logout' | 'user' | 'dot';

interface Props extends Omit<SVGProps<SVGSVGElement>, 'name'> {
  name: IconName;
  size?: number;
}

/**
 * Single-source-of-truth icon set. Thin (1.5) consistent strokes,
 * 24px viewBox, currentColor — keeps the UI quiet and aligned.
 */
export default function Icon({ name, size = 20, ...rest }: Props) {
  const stroke = {
    width: size,
    height: size,
    viewBox: '0 0 24 24',
    fill: 'none',
    stroke: 'currentColor',
    strokeWidth: 1.5,
    strokeLinecap: 'round' as const,
    strokeLinejoin: 'round' as const,
    ...rest,
  };

  switch (name) {
    case 'board':
      return (
        <svg {...stroke}>
          <rect x="3.5" y="4.5" width="17" height="15" rx="2.5" />
          <line x1="3.5" y1="9" x2="20.5" y2="9" />
          <line x1="9" y1="9" x2="9" y2="19.5" />
        </svg>
      );

    case 'logout':
      return (
        <svg {...stroke}>
          <path d="M14 4.5h4.5A1.5 1.5 0 0 1 20 6v12a1.5 1.5 0 0 1-1.5 1.5H14" />
          <path d="M9.5 8.5 6 12l3.5 3.5" />
          <line x1="6" y1="12" x2="14.5" y2="12" />
        </svg>
      );

    case 'user':
      return (
        <svg {...stroke}>
          <circle cx="12" cy="8.5" r="3.5" />
          <path d="M5 19c1.5-3 4-4.5 7-4.5s5.5 1.5 7 4.5" />
        </svg>
      );

    case 'dot':
      return (
        <svg
          width={size}
          height={size}
          viewBox="0 0 24 24"
          fill="currentColor"
          {...rest}
        >
          <circle cx="12" cy="12" r="4" />
        </svg>
      );

    case 'discord':
      return (
        <svg
          width={size}
          height={size}
          viewBox="0 0 24 24"
          fill="currentColor"
          {...rest}
        >
          <path d="M19.27 5.33a16.92 16.92 0 0 0-4.18-1.3.06.06 0 0 0-.07.03c-.18.32-.38.74-.52 1.07a15.65 15.65 0 0 0-4.7 0 11.18 11.18 0 0 0-.53-1.07.07.07 0 0 0-.07-.03 16.87 16.87 0 0 0-4.18 1.3.06.06 0 0 0-.03.02C2.42 9.36 1.69 13.27 2.05 17.13a.07.07 0 0 0 .03.05 17 17 0 0 0 5.12 2.59.07.07 0 0 0 .07-.02c.39-.54.74-1.1 1.04-1.69a.07.07 0 0 0-.04-.09 11.21 11.21 0 0 1-1.6-.76.07.07 0 0 1-.01-.11l.32-.25a.07.07 0 0 1 .07-.01 12.13 12.13 0 0 0 10.32 0 .07.07 0 0 1 .07.01l.32.25a.07.07 0 0 1-.01.11c-.51.3-1.04.55-1.6.76a.07.07 0 0 0-.04.09c.31.59.66 1.15 1.04 1.69a.07.07 0 0 0 .07.02 16.95 16.95 0 0 0 5.13-2.59.07.07 0 0 0 .03-.05c.43-4.46-.72-8.34-3.04-11.78a.05.05 0 0 0-.03-.02ZM8.52 14.78c-1.01 0-1.85-.93-1.85-2.07s.82-2.07 1.85-2.07c1.04 0 1.87.94 1.85 2.07 0 1.14-.82 2.07-1.85 2.07Zm6.84 0c-1.01 0-1.85-.93-1.85-2.07s.82-2.07 1.85-2.07c1.04 0 1.87.94 1.85 2.07 0 1.14-.81 2.07-1.85 2.07Z" />
        </svg>
      );

    default:
      return null;
  }
}
