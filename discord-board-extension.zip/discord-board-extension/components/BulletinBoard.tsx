'use client';

import { useEffect } from 'react';
import { useUsers } from '@/hooks/useUsers';
import UserCard from './UserCard';
import type { BoardUser } from '@/lib/types';

interface Props {
  initial: BoardUser[];
  currentDiscordId: string;
}

const HEARTBEAT_MS = 60_000;

export default function BulletinBoard({ initial, currentDiscordId }: Props) {
  const users = useUsers(initial);

  // Presence heartbeat: refresh `last_seen` for the current user.
  useEffect(() => {
    let cancelled = false;

    const ping = () => {
      if (cancelled || document.visibilityState !== 'visible') return;
      fetch('/api/presence', { method: 'POST', credentials: 'same-origin' }).catch(
        () => {
          /* swallow — presence is best-effort */
        },
      );
    };

    ping();
    const id = window.setInterval(ping, HEARTBEAT_MS);
    const onVis = () => {
      if (document.visibilityState === 'visible') ping();
    };
    document.addEventListener('visibilitychange', onVis);

    return () => {
      cancelled = true;
      window.clearInterval(id);
      document.removeEventListener('visibilitychange', onVis);
    };
  }, []);

  if (users.length === 0) {
    return (
      <div className="empty fade-in">
        <p>No one&rsquo;s here yet.</p>
      </div>
    );
  }

  return (
    <div className="board-grid">
      {users.map((u, idx) => (
        <UserCard
          key={u.id}
          user={u}
          isCurrent={u.discord_id === currentDiscordId}
          delay={Math.min(idx * 30, 480)}
        />
      ))}
    </div>
  );
}
