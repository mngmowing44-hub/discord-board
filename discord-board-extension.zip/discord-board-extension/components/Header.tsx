import Icon from './Icon';

interface Props {
  username: string;
}

export default function Header({ username }: Props) {
  return (
    <header className="site-header">
      <div className="site-header__brand">
        <Icon name="board" size={18} />
        <span>discord-board</span>
      </div>

      <div className="site-header__right">
        <span className="site-header__user" title={username}>
          {username}
        </span>
        <form action="/api/auth/logout" method="POST">
          <button className="ghost-btn" type="submit" aria-label="Sign out">
            <Icon name="logout" size={14} />
            <span>Sign out</span>
          </button>
        </form>
      </div>
    </header>
  );
}
