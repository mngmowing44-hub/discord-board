import Icon from './Icon';

export default function LoginButton() {
  return (
    <a className="login-btn" href="/api/auth/login">
      <Icon name="discord" size={18} />
      <span>Continue with Discord</span>
    </a>
  );
}
