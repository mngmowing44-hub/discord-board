'use client';

import { useMemo } from 'react';
import type { BoardUser } from '@/lib/types';
import { accountAge, snowflakeToDate } from '@/lib/auth/snowflake';
import { relativeTime } from '@/lib/format';
import Icon from './Icon';

interface Props {
  user: BoardUser;
  isCurrent?: boolean;
  delay?: number;
}

export default function UserCard({ user, isCurrent, delay = 0 }: Props) {
  const banner = useMemo(() => {
    if (user.banner_url) return { type: 'image' as const, value: user.banner_url };
    if (user.banner_color) return { type: 'color' as const, value: user.banner_color };
    return { type: 'fallback' as const, value: null };
  }, [user.banner_url, user.banner_color]);

  const seen = relativeTime(user.last_seen);
  const isOnline = seen === 'online';
  const joined = snowflakeToDate(user.discord_id);
  const age = accountAge(user.discord_id);

  return (
    <article
      className="user-card fade-in"
      style={{ animationDelay: `${delay}ms` }}
    >
      <div
        className={`user-card__banner user-card__banner--${banner.type}`}
        style={
          banner.type === 'image'
            ? { backgroundImage: `url(${banner.value})` }
            : banner.type === 'color'
            ? { background: banner.value }
            : undefined
        }
        aria-hidden
      />

      <div className="user-card__body">
        <div className="user-card__avatar-wrap">
          {user.avatar_url ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img
              className="user-card__avatar"
              src={user.avatar_url}
              alt=""
              loading="lazy"
            />
          ) : (
            <div
              className="user-card__avatar user-card__avatar--placeholder"
              aria-hidden
            >
              {user.username.slice(0, 1).toUpperCase()}
            </div>
          )}
        </div>

        <div className="user-card__heading">
          <h3 className="user-card__name">{user.username}</h3>
          {isCurrent && <span className="user-card__pill">You</span>}
        </div>

        {user.bio && <p className="user-card__bio">{user.bio}</p>}

        <dl className="user-card__meta">
          <div>
            <dt>On Discord</dt>
            <dd title={joined.toLocaleDateString()}>{age}</dd>
          </div>
          <div>
            <dt>Last seen</dt>
            <dd className={isOnline ? 'is-online' : undefined}>
              {isOnline && <Icon name="dot" size={8} aria-hidden />}
              {seen}
            </dd>
          </div>
        </dl>
      </div>
    </article>
  );
}
