-- =============================================================================
-- discord-board: users directory schema
-- This migration has already been applied to the Supabase project
-- "discord board" (ref: ofnruxbhaxhrvcubuvbs).
-- It is committed here for repo parity / disaster recovery / branching.
-- =============================================================================

create table public.users (
  id uuid primary key default gen_random_uuid(),
  discord_id text unique not null,
  username text not null,
  avatar_url text,
  banner_url text,
  banner_color text,
  bio text,
  account_created_at timestamptz not null,
  last_seen timestamptz not null default now(),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index users_last_seen_idx on public.users (last_seen desc);

create or replace function public.handle_updated_at()
returns trigger
language plpgsql
set search_path = ''
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

create trigger users_updated_at
before update on public.users
for each row execute function public.handle_updated_at();

-- RLS: anyone can read, only service_role writes.
alter table public.users enable row level security;

create policy "users_select_all"
on public.users
for select
to anon, authenticated
using (true);

-- Realtime
alter publication supabase_realtime add table public.users;
