'use client';

import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabase/client';
import type { BoardUser } from '@/lib/types';

/**
 * Subscribes to INSERT/UPDATE/DELETE on `public.users` and keeps a
 * client-side list in sync, sorted by `last_seen` desc.
 */
export function useUsers(initial: BoardUser[]): BoardUser[] {
  const [users, setUsers] = useState<BoardUser[]>(initial);

  useEffect(() => {
    const sortByLastSeen = (a: BoardUser, b: BoardUser) =>
      new Date(b.last_seen).getTime() - new Date(a.last_seen).getTime();

    const channel = supabase
      .channel('public:users')
      .on(
        'postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'users' },
        (payload) => {
          setUsers((prev) => {
            const incoming = payload.new as BoardUser;
            if (prev.some((u) => u.id === incoming.id)) return prev;
            return [incoming, ...prev].sort(sortByLastSeen);
          });
        },
      )
      .on(
        'postgres_changes',
        { event: 'UPDATE', schema: 'public', table: 'users' },
        (payload) => {
          setUsers((prev) => {
            const incoming = payload.new as BoardUser;
            const idx = prev.findIndex((u) => u.id === incoming.id);
            const next = idx === -1 ? [incoming, ...prev] : prev.map((u, i) => (i === idx ? incoming : u));
            return next.sort(sortByLastSeen);
          });
        },
      )
      .on(
        'postgres_changes',
        { event: 'DELETE', schema: 'public', table: 'users' },
        (payload) => {
          const old = payload.old as Partial<BoardUser>;
          setUsers((prev) => prev.filter((u) => u.id !== old.id));
        },
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  return users;
}
